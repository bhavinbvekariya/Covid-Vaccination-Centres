/**
 * @file
 * cvc behaviors.
 */

(function ($, Drupal) {

  'use strict';

  /**
   * Behavior description.
   */
  Drupal.behaviors.cvc = {
    attach: function (context, settings) {

      console.log('It works!');

    }
  };

} (jQuery, Drupal));
;
